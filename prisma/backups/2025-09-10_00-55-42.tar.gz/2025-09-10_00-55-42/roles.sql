
\restrict pwvatB1iidI0WpgX4iu5sFG7O6GH9saBOCkl8tLQbZ4YWqt7qB08JyGocag5ZAx

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

ALTER ROLE "anon" SET "statement_timeout" TO '3s';

ALTER ROLE "authenticated" SET "statement_timeout" TO '8s';

ALTER ROLE "authenticator" SET "statement_timeout" TO '8s';

\unrestrict pwvatB1iidI0WpgX4iu5sFG7O6GH9saBOCkl8tLQbZ4YWqt7qB08JyGocag5ZAx

RESET ALL;
