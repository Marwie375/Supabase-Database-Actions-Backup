
\restrict Vj9T5XI9cxvPHSJqScDuIbX7FcBD8lo3295Ocj7apP5TEcgn8pRcSnW6hnuGjuW

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

ALTER ROLE "anon" SET "statement_timeout" TO '3s';

ALTER ROLE "authenticated" SET "statement_timeout" TO '8s';

ALTER ROLE "authenticator" SET "statement_timeout" TO '8s';

\unrestrict Vj9T5XI9cxvPHSJqScDuIbX7FcBD8lo3295Ocj7apP5TEcgn8pRcSnW6hnuGjuW

RESET ALL;
